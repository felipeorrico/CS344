Assignment 5 - ReadMe - Felipe Orrico Scognamiglio (933-327-510)

1) The Functions:
    I) Please contact me using my OSU email (orricosf@oregonstate.edu) in case there is any part of the code that requires some explanation.
    We can schedule some time on Zoom to address that.
		II) All functions for ENC_SERVER and DEC_SERVER can be found in ServerAPI.c

2) Compiling the Code:
    I) I added a Makefile to compile the code. All you have to do is run "make" or "make all" to create the 5 executable files.
    II) To clear all the made files run "make clean"
    III) If the Makefile does not work use ./CompileAll
		IV) You can clean the created files after the script with ./ClearAll

4) In case of Corrupt files:
	I post all my assignments on GitHub! https://github.com/felipeorrico/CS344

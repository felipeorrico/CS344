/***********************************************************************
** File: dec_server.c
** Author: Felipe Orrico Scognamiglio
** Class: CS344 F2020
** Instructor: Justin Goins
** Assignment: One-Time Pads (Assignment 5)
** Final Version Date: 11/27/2020
***********************************************************************/

#include "ServerAPI.h"

int main(int argc, char*argv[]){
	runServer(argc, argv, 0);
}

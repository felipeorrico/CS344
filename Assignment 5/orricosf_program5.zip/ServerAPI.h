#ifndef SERVERAPI
#define SERVERAPI

int runServer(int argc, char*argv[], int option);

#endif
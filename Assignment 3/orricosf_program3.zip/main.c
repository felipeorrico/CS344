#include "./Utils/intList.h"
#include "./Utils/linkedlist.h"
#include "./Utils/utils.h"
#include "./Built-in/cd.h"
#include "./Built-in/exit.h"
#include "./Shell/Shell.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

int main(){

    Shell_run();

}
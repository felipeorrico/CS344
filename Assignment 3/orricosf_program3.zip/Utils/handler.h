#ifndef HANDLER_H
#define HANDLER_H

void Handler_KillFG(int signum);
void Handler_SetFGOnly(int signum);

#endif